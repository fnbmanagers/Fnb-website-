FNB MANAGER WEBSITE - HOW TO PUBLISH (free, Netlify Drop)

Folder layout
 /index.html            landing page with packages
 /app/index.html        the restaurant app (orders, kitchen, billing, bar, reports)
 /admin/index.html      admin dashboard (admin and team sign-in)
 /subscribe/index.html  package purchase page (Razorpay / BillDesk)
 /privacy/index.html    privacy policy (draft)
 /terms/index.html      terms of use (draft)

Publish
 1. Go to app.netlify.com/drop and drag this whole folder onto the page.
 2. You get an address such as https://your-site.netlify.app. Rename the site in Netlify settings if you want.
 3. Add your own domain later from Netlify > Domain settings.

Before publishing, replace the placeholders
 - support@fnbmanagers.com,  on the landing, privacy and terms pages, and in admin reminder emails
 - Optimistix Technologies and Solutions, Shendra, Chhatrapati Sambhajinagar, [CITY], [DATE] in privacy and terms (counsel must review)
 - Payment page links and SUPPORT_WA in subscribe/index.html
 - SUPPORT.wa in app/index.html (support WhatsApp for in-app reports)

Important limits
 - Each restaurant's data stays on its own device. The admin dashboard sees only what is imported.
 - Subscriptions are not enforced in the app yet, and payments are checked by hand.
 - Automatic activation and live data need a shared database and payment webhooks (Firebase or similar).
